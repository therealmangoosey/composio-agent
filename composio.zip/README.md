# Tab Assistant

One pure-Python personal AI assistant for Termux: a numbered terminal app and an
optional Discord bot using the same `data/config.json` and conversation storage.

## Install in Termux

```sh
pkg update && pkg install python -y
pip install openai requests discord.py
# Optional: real Gmail/web/news tools via Composio
pip install composio composio-openai
python app.py
```

Run the bot directly with `python app.py --bot`. For background use: `tmux new -s ai`,
then run the bot and detach with `Ctrl-b d`.

On first run, the wizard creates `data/config.json` for preferences and `.env` for
all secrets. It never prints keys. Do not commit `.env` (the included `.gitignore`
already excludes it).
Get provider keys from [Groq](https://console.groq.com), [Gemini](https://aistudio.google.com),
[OpenAI](https://platform.openai.com), [OpenRouter](https://openrouter.ai/keys),
[Cerebras](https://cloud.cerebras.ai), [DeepSeek](https://platform.deepseek.com),
[xAI](https://console.x.ai), and [Composio](https://platform.composio.dev).

For Discord: enable Developer Mode, create an App/Bot in the Discord Developer Portal,
invite it with `bot` and `applications.commands` scopes, then copy the channel ID into
the wizard. The bot ignores DMs and every channel except that ID.

Free mode rotates free marked keys/models and retains the last successful one. Auto also
tries paid keys. Any plan that includes a tool action must be confirmed: `y/N` in the
terminal or buttons in Discord. Local notes and CSV leads always work; Composio actions
need its SDK and an OAuth connection.

Model identifiers change over time; edit the `models` arrays in `data/config.json`.
Use `python app.py --debug` only when troubleshooting: tracebacks otherwise stay in
`data/errors.log`.
